
import com.ibm.mq.MQGetMessageOptions;
import com.ibm.mq.MQMessage;
import com.ibm.mq.MQQueue;
import com.ibm.mq.MQQueueManager;
import com.ibm.mq.constants.MQConstants;

import java.util.Hashtable;

//import lrapi.lr;

public class Actions {
    public static void main(String[] args) {
        Actions actions  = new Actions();
        try {
//            Locale.setDefault(Locale.UNICODE_LOCALE_EXTENSION);
            actions.init();
            actions.action();
            actions.end();
        } catch (Throwable throwable) {
            throwable.printStackTrace();
        }
    }

    String hostname="10.45.37.207";
    int port=1414;
    String channel = "SYSTEM.BKR.CONFIG";
    String userId="";
    String password = "";
    String queueMgrName = "QM1";


    MQQueueManager queueMgr = null;
    MQQueue getQueue = null;
    MQQueue putQueue = null;
    //MQPutMessageOptions pmo = new MQPutMessageOptions();
    MQGetMessageOptions gmo = new MQGetMessageOptions();
    //MQMessage requestMsg = new MQMessage();
    MQMessage responseMsg = new MQMessage();
    String msgBody = null;
//    String outputFlg = lr.get_attrib_string("outputFlag");

    private Hashtable getMqProperties() {
        Hashtable<Object, Object> ht = new Hashtable<Object, Object>();
        ht.put(MQConstants.HOST_NAME_PROPERTY, hostname);
        ht.put(MQConstants.CHANNEL_PROPERTY, channel);
        ht.put(MQConstants.USER_ID_PROPERTY, userId);
        ht.put(MQConstants.PASSWORD_PROPERTY, password);
        ht.put(MQConstants.PORT_PROPERTY, port);
        return ht;
    }

    public int init() throws Throwable {




        try {

            queueMgr = new MQQueueManager(queueMgrName,getMqProperties());

            //putQueue = queueMgr.accessQueue("RB.RTDM.IN", MQConstants.MQOO_OUTPUT | MQConstants.MQOO_FAIL_IF_QUIESCING);
            getQueue = queueMgr.accessQueue("TRASH.LETTER.QUEUE", MQConstants.MQOO_INPUT_AS_Q_DEF | MQConstants.MQOO_OUTPUT | MQConstants.MQOO_INQUIRE);
        } catch(Exception e) {
            System.out.println("Error connecting to queue manager or accessing queues.");

        }


        return 0;

    }//end of init


    public int action() throws Throwable {
        int currentDepth = 0;
        try{

            currentDepth = getQueue.getCurrentDepth();
            while(currentDepth > 0) {
                MQMessage message = new MQMessage();
                System.out.println(getQueue.getCurrentDepth());
                getQueue.get(message);
                byte[] b = new byte[message.getMessageLength()];
                message.readFully(b);
                String s = new String(b, "UTF-8");
                System.out.println(s);
                message.clearMessage();
                Thread.sleep(100);
                currentDepth = getQueue.getCurrentDepth();
            }

        }catch (Exception e){
            end();
            e.printStackTrace();
        }
        Thread.sleep(100);

        return 0;
    }//end of action


    public int end() throws Throwable {


        try {
            //putQueue.close();
            getQueue.close();
            queueMgr.close();
        } catch(Exception e) {
            System.out.println("Exception in closing the connections");
        }


        return 0;
    }//end of end
}
