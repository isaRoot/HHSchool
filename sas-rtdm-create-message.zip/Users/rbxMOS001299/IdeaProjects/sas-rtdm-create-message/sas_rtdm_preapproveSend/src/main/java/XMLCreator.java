
import lrapi.lr;

import java.io.*;
import java.nio.charset.Charset;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class XMLCreator{

    static Map<String, String> data;

    public XMLCreator(List<Map<String, String>> list) {
        int size = list.size();
        if(size <= 0) throw new RuntimeException("no Data for this XML type in datapool");
        if(size == 1) data = list.get(0);
        int rnd = new Random().nextInt(size - 1);
        data = list.get(rnd);
    }

    private String getXMLContent(){
        String strpath = "zXML.ACRM.PREAPPROVE.xml";
        Path path = Paths.get(strpath);
        String res = "";
        try{
            List<String> contents = Files.readAllLines(path, Charset.forName("UTF-8"));

            for(String content:contents){
                String tmp = res + content;
                res = tmp;
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        return res;
    }

    String createPoolStringProduct(BufferedReader _br, String _product) throws FileNotFoundException, IOException{
        String localString = null;
        while((localString = _br.readLine()) != null){
            if(localString.contains(_product)){
                return localString;
            }
        }
        return null;
    }

    HashMap parsePoolFileProduct(String _path, String _product) throws FileNotFoundException, IOException{
        FileInputStream fstream = new FileInputStream(_path);
        BufferedReader br = new BufferedReader(new InputStreamReader(fstream));

        HashMap<String, String> dataMap = new HashMap<String, String>();

        List<String> headerList = Arrays.asList(br.readLine().split("\t"));
        List<String> dataList = Arrays.asList(createPoolStringProduct(br, _product).split("\t"));
        br.close(); fstream.close();

        for(int i = 0; i <= headerList.size()-1; i++) dataMap.put(headerList.get(i), dataList.get(i));
        return dataMap;
    }

    String generateRandomCharCount(int _count, boolean _upperCase){
        //String rus = "абвгдеёжзийклмнопрстуфхцчъыьэюя";
        String eng = "abcdefghijklmnopqrstuvwxyz";
        String dig = "0123456789";
        if(_upperCase) eng = eng.toUpperCase();
        String chars = /*rus +*/ eng + dig;
        Random rnd = new Random(System.currentTimeMillis());

        String outString = "";
        for(int i = 0; i < _count; i++){
            outString += chars.charAt(rnd.nextInt(chars.length()) );
        }
        return outString;
    }

    String randomCodeFormat(String _formatString, boolean _upperCase) throws InterruptedException{
        String outString = "";
        int startid = _formatString.indexOf("%"), endid = 0;
        if(startid != -1){
            endid = _formatString.indexOf("%", startid+1);

            int encCount = Integer.parseInt(_formatString.substring(startid+1, endid));
            Thread.sleep(10);

            outString = randomCodeFormat(_formatString.substring(0, startid)+
                            generateRandomCharCount(encCount, _upperCase)+
                            _formatString.substring(endid+1, _formatString.length()),
                    _upperCase);
            return outString;
        }
        return _formatString;
    }

    int randomIntBounds(int _lb, int _rb){
        Random rnd = new Random();
        if((_rb - _lb) <= 0){
            if(_lb >= 0){
                return _lb;
            }else{
                return 0;
            }
        }
        return _lb + rnd.nextInt(_rb - _lb);
    }

    Date addDays(Date _date, int _days){
        Calendar c = Calendar.getInstance();
        c.setTime(_date);
        c.add(Calendar.DATE, 1);
        return c.getTime();
    }

    public String getMsg() throws InterruptedException, IOException{
        String msgBody = null;
        String msgTemplate = null;

        SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd'T'hh:mm:ss");
        SimpleDateFormat dateFormat2 = new SimpleDateFormat("MM/dd/yyyy hh:mm:ss");//08/30/2018 00:00:01

        data.put("Applicant.Client_ID", randomCodeFormat("1-%7%", true)); //"1-10JMQCV",
        data.put("Application.MA_application_ID", lr.eval_string("{rand8l}_") + data.get("Applicant.Client_ID")); //"13800201_1-10JMQCV"//"13800201_" + data.get("Applicant.Client_ID");
        data.put("Application.Ext_Request_ID", data.get("Application.MA_application_ID")); //"13800201_1-10JMQCV"//"13800201_" + data.get("Applicant.Client_ID");
        data.put("Application.App_ID", "ACRM_" + data.get("Application.Ext_Request_ID")); //"ACRM_13800201_1-10JMQCV"//"ACRM_" + data.get("Application.Ext_Request_ID")
        data.put("Applicant.Applicant_ID", data.get("Application.App_ID") + data.get("Applicant.Client_ID")); //ACRM_13800201_1-10JMQCV1-10JMQCV

        //data.put("Applicant.Sex", lr.get_attrib_string("sex"));
        data.put("Applicant.Client_Car_Owner", lr.get_attrib_string("auto"));
        data.put("Applicant.Client_Realty_Owner", lr.get_attrib_string("realty"));
        if(lr.get_attrib_string("income").equals("Y")){
            data.put("Applicant.After_Tax_Official_Income", lr.eval_string("{income_high}.00"));
        }else{
            data.put("Applicant.After_Tax_Official_Income", lr.eval_string("{income_low}.00"));
        }
        data.put("MessageID", randomCodeFormat("%8%-%4%-%4%-%4%-%12%", false)); //"6d341200-bd6d-4c44-a25c-abf7c7ddc5a8",
        data.put("CorrelationID", randomCodeFormat("%48%", false)); //"414d5120514d31202020202020202020dd1b305be174a826",
        data.put("ScoreCustomerObjectID", data.get("Application.App_ID").substring(0,9));

        data.put("Doc_Series", Integer.toString(randomIntBounds(1000, 9999)));
        data.put("Doc_Number", Integer.toString(randomIntBounds(100000, 999999)));
        data.put("Doc_Issue_Date", dateFormat.format(new Date(-946771200000L + (Math.abs(new Random().nextLong()) % (77L * 365 * 24 * 60 * 60 * 1000)))));
        lr.output_message("Doc_Issue_Date: " + data.get("Doc_Issue_Date"));

        dataToParams();
        String tmpxmlval = getXMLContent();
        System.out.println(tmpxmlval);
        System.out.println();
        msgTemplate = lr.eval_string(tmpxmlval);

        String outputFlg = lr.get_attrib_string("outputFlag");
        if(outputFlg.equals("MQ")){
            msgBody = removeEmptyTags(msgTemplate);

        } else {
            msgBody = removeEmptyTags(msgTemplate);
        }
        lr.output_message(msgBody);
        return msgBody;
    }

    String removeEmptyTags(String msgTemplate){
        final String regex1 = "<([a-zA-Z0-9-\\_]*)[^>]*/>";
        final String regex2 = "<([a-zA-Z0-9-\\_]*)[^>]*></\\1>";
        //final String regex2 = "<([a-zA-Z0-9-\\_]*)[^>]*>\\s*</\\1>";

        final Pattern pattern1 = Pattern.compile(regex1);
        final Pattern pattern2 = Pattern.compile(regex2);

        Matcher matcher1;
        Matcher matcher2;
        do {
            msgTemplate = msgTemplate.replaceAll(regex1, "").replaceAll(regex2, "");
            matcher1 = pattern1.matcher(msgTemplate);
            matcher2 = pattern2.matcher(msgTemplate);
        } while (matcher1.find() || matcher2.find());
        return msgTemplate;
    }

    void dataToParams(){
        String str = data.get("Applicant.Other_Monthly_Payment");
        data.replace("Applicant.Other_Monthly_Payment", str.replace(",", "."));
        str = data.get("Applicant.Declared_AVG_Monthly_Income");
        data.replace("Applicant.Declared_AVG_Monthly_Income", str.replace(",", "."));
        str = data.get("Applicant.After_Tax_Official_Income");
        data.replace("Applicant.After_Tax_Official_Income", str.replace(",", "."));
        str = data.get("Applicant.Salary_Income_To_Account");
        data.replace("Applicant.Salary_Income_To_Account", str.replace(",", "."));
        str = data.get("Applicant.Birth_Date");
        if(!(str.equals("null"))){
            try{
                SimpleDateFormat dateFormat = new SimpleDateFormat("dd.MM.yyyy");
                Date date = dateFormat.parse(str);
                SimpleDateFormat dateFormat2 = new SimpleDateFormat("yyyy-MM-dd");
                str = dateFormat2.format(date);
            }catch(Exception e){
                lr.error_message("dateFormat error on value \"Applicant.Birth_Date\"");
                lr.error_message("Converting dateFormat from \"dd.MM.yyyy\" to \"yyyy-MM-dd\" failed. \r\n Your Input value: " + str + " not supported");
            }
            data.replace("Applicant.Birth_Date", str);
        }

        lr.save_string("", "BIS_Client");//Заделка к блоку бис-данных
        if(!data.get("Applicant.BISClientCount").equals("0"))
            makeBisBlock();
        for (String key:data.keySet()){
            if(data.get(key).equals("null")){
                lr.save_string("", key);
            }else{
                lr.save_string(data.get(key), key);
            }
        }
    }

    void makeBisBlock(){

        FileInputStream fstream = null;
        try {
            fstream = new FileInputStream("BIS_pool.txt");
            BufferedReader br = new BufferedReader(new InputStreamReader(fstream));
            String[] tmp = null;
            String line = null;
            List<String> bis_client_id = new ArrayList<String>();
            List<String> bis_branch_id = new ArrayList<String>();
            while((line = br.readLine()) != null){
                tmp = line.split("\t");
                bis_client_id.add(tmp[0]);
                bis_branch_id.add(tmp[1]);
                tmp = null;
                line = null;
            }
            br.close(); fstream.close();
            int size = bis_client_id.size();
            System.out.println("size: " + size);
            if(size > 0){
                int r_int = randomIntBounds(0, size - 1);
                //<BIS_Client><BIS_Client_ID>1D1738</BIS_Client_ID><Branch_BIS_ID>R19</Branch_BIS_ID></BIS_Client>
                String res = "<BIS_Client><BIS_Client_ID>" + bis_client_id.get(r_int) +
                        "</BIS_Client_ID><Branch_BIS_ID>" + bis_branch_id.get(r_int) + "</Branch_BIS_ID></BIS_Client>";

                lr.save_string(res, "BIS_Client");
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}