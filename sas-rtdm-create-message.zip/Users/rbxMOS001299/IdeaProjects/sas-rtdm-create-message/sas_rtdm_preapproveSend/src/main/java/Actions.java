import lrapi.lr;
import org.apache.activemq.ActiveMQConnectionFactory;

import javax.jms.*;
import java.util.ArrayList;
import java.util.Hashtable;
import java.util.List;
import java.util.Map;

/*
 * LoadRunner Java script. (Build: _build_number_)
 *
 * Script Description:
 *  Java JDK on Generators - C:\Program Files (x86)\Java\jdk1.8.0_151
 */
//import EPD;

public class Actions
{
    /*4 ActiveMQ*/
    //String url = "tcp://rsb-ascmosrtdm1.rosbank.rus.socgen:62626";
    //String url2 = "tcp://rsb-ascmosrtdm2.rosbank.rus.socgen:62626";
    String url = lr.get_attrib_string("url");

    /*?*/	String subject = "QUEUE.INBOX"; // Queue Name.You can create any/many queue names as per your requirement.
    /*4 ActiveMQ*/
    String queueNameIn = lr.get_attrib_string("queueNameIn");//"RB.RTDM.IN"
    String queueNameOut = lr.get_attrib_string("queueNameOut");//"RB.DST.OUT"
    static List<Map<String, String>> noBisPoolList;
    static List<Map<String, String>> bisPoolList;
    static List<List<Map<String, String>>> poolList = null;
    static List<String> poolHeaders = null;

    //ConnectionFactory conn = new ActiveMQConnectionFactory("username", "password", url);
    ConnectionFactory connectionFactory;
    Connection connection;
    Session session;
    Destination destination;
    MessageProducer producer;
    TextMessage message;


    boolean debug = (lr.get_attrib_long("DEBUG") == 1);
    int bis_procent = (int)lr.get_attrib_long("bis_procent");

    String msgBody = null;
    Hashtable<Object, Object> ht = null;

    String outputFlg = lr.get_attrib_string("outputFlag");

    public int init() throws Throwable {
        lr.output_message(url);
        url = lr.eval_string(url);
        lr.output_message(url);
        //lr.abort();
        if((noBisPoolList == null) && (bisPoolList == null)){
            Datapool datapool = new Datapool("pool.txt");
            String xmlType = lr.get_attrib_string("sex");
            datapool.needOnly(xmlType, true);
            noBisPoolList = datapool.getNoBisPoolList();
            bisPoolList = datapool.getBisPoolList();
        }
        if(debug){
            Datapool datapool = new Datapool("pool.txt");
            poolList = new ArrayList<List<Map<String, String>>>();
            poolHeaders = datapool.getPoolKeys();
            for (String str : poolHeaders) {
                datapool.needOnly(str);
                poolList.add(datapool.getBisPoolList());
                poolList.add(datapool.getNoBisPoolList());
                lr.output_message(str);
            }

            poolHeaders = null;
        }
        if(outputFlg.equals("MQ")){
            try{
                //String username = "drkr";
                //String password = "drkr_rtdm";
                //connectionFactory = new ActiveMQConnectionFactory(username, password, url);
                connectionFactory = new ActiveMQConnectionFactory(url);
                lr.output_message("connectionFactory = new ActiveMQConnectionFactory(url);");
                connection = connectionFactory.createConnection();
                lr.output_message("connection = connectionFactory.createConnection();");
                //Creating a non transactional session to send/receive JMS message.
                session = connection.createSession(false, Session.AUTO_ACKNOWLEDGE);
                lr.output_message("session = connection.createSession(false, Session.AUTO_ACKNOWLEDGE);");
                destination = session.createQueue(subject);
                lr.output_message("destination = session.createQueue(subject);");
                // MessageProducer is used for sending messages to the queue.
                producer = session.createProducer(destination);
                lr.output_message("producer = session.createProducer(destination);");
                connection.start();
                lr.output_message("connection.start();");
            } catch(Exception e) {
                lr.error_message(e.toString());
                lr.error_message("Error connecting to queue manager or accessing queues.");
                lr.exit(lr.EXIT_VUSER, lr.FAIL);
            }
        }

        return 0;

    }//end of init


    public int action() throws Throwable {
        XMLCreator requestMsg;
        String transactionName = "";

        if(!debug){
            poolList = new ArrayList<List<Map<String, String>>>();
            poolList.add(bisPoolList);//if only bis data - keep it commented, and uncommented current line
            /*if (lr.eval_int("{bis_rand}") <= bis_procent) {
                poolList.add(bisPoolList);
            } else {
                poolList.add(noBisPoolList);
            }*/
        }

        for (List<Map<String, String>> data: poolList) {
            String isBis = "";/**
             if(data.get(0).get("Applicant.BISClientCount").equals("0"))
             lr.save_string(".noBIS", "isBis");
             //isBis = ".noBIS";
             else lr.save_string(".BIS", "isBis");//isBis = ".BIS";/**/

            lr.output_message(transactionName);
            requestMsg = new XMLCreator(data);
            String requestMsgBody = requestMsg.getMsg();
            if (outputFlg.equals("console")) {
                System.out.println(requestMsgBody);
            } else if (outputFlg.equals("MQ")) {
//    			requestMsg.clearMessage();
                lr.start_transaction(lr.eval_string("SendToActiveMQ_{Application.Request_Type}"));
                //lr.output_message("SendToMQ_" + data.get(0).get("Application.Request_Type") + "." + data.get(0).get("Application.Channel") + "." + data.get(0).get("Application.Product.Macroproduct") + isBis);
                lr.output_message(lr.eval_string("SendToActiveMQ_{Application.Request_Type}"));
                sendMessage2MQ(requestMsgBody);
                lr.end_transaction(lr.eval_string("SendToActiveMQ_{Application.Request_Type}"), lr.AUTO);
            } else {
                System.out.println("неизвестный признак вывода");
            }
            transactionName = "";
            lr.think_time(1);
        }

        return 0;
    }//end of action

    public void sendMessage2MQ(String requestMsgBody){
        try {
            message = session.createTextMessage(requestMsgBody);
            message.setJMSType("ACRM");
            producer.send(message);

            System.out.println("message.getJMSMessageID(): " + message.getJMSMessageID());
            System.out.println("message.getText(): " + message.getText());

        } catch(Exception e) {
            lr.error_message("Error sending message.");
            lr.exit(lr.EXIT_VUSER, lr.FAIL);
        }finally{
            message = null;
        }
    }

    public int end() throws Throwable {

        if(outputFlg.equals("MQ")){
            try {
                connection.close();
                ht = null;
            } catch(Exception e) {
                lr.error_message("Exception in closing the connections");
                lr.exit(lr.EXIT_VUSER, lr.FAIL);
            }
        }

        return 0;
    }//end of end
}
