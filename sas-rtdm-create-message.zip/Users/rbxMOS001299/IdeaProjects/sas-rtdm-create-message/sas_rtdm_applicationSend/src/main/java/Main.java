//package ru.iteco.isa.lr.script.SAS_RTDM_ApplicationSend;

//import lrapi.lr;
public class Main {
    public static void main(String[] args) throws Exception {
        Actions actions = new Actions();
        try {
            actions.init();
            actions.action();
            actions.end();
        } catch (Throwable throwable) {
            throwable.printStackTrace();
        }
        System.out.println();
    }

}
