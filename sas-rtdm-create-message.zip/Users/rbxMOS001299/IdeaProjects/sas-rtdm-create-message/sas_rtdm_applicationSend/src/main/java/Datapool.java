//package ru.iteco.isa.lr.script.SAS_RTDM_ApplicationSend;

import java.io.*;
import java.util.*;

public class Datapool {
    private static String poolFilePath = "pool.txt";
    private HashMap<String, List<List<String>>> pool;
    private List<String> headers;
    private List<Map<String, String>> noBisPoolList = new ArrayList<>();
    private List<Map<String, String>> bisPoolList = new ArrayList<>();

    public List<Map<String, String>> getNoBisPoolList() {
        return noBisPoolList;
    }

    public List<Map<String, String>> getBisPoolList() {
        return bisPoolList;
    }

    public Datapool() throws IOException {
        init();
    }

    public Datapool(String poolFilePath, String xmlType) throws IOException {
        Datapool.poolFilePath = poolFilePath;
        init();
        needOnly(xmlType);
    }

    Datapool(String poolFilePath) throws IOException {
        Datapool.poolFilePath = poolFilePath;
        init();
    }

    private void init() throws IOException {
        pool = parsePoolFile(poolFilePath);
    }

    private static List<List<String>> list2listlist(List<String> list){
        List<List<String>> listlist = new ArrayList<>();
        listlist.add(list);
        return listlist;
    }

    private HashMap parsePoolFile(String _path) throws IOException{
        FileInputStream fstream = new FileInputStream(_path);
        BufferedReader br = new BufferedReader(new InputStreamReader(fstream));
        HashMap<String, List<List<String>>> datapool = new HashMap<>();

        List<String> headerList = Arrays.asList(br.readLine().split("\t"));
        headers = headerList;
        //List<String> dataList = Arrays.asList(createPoolStringRandom(br, 100).split("\t"));
        datapool.put("Headers", list2listlist(headerList));
        List<List<String>> listlist = new ArrayList<>();

        String localString = null;
        for(int i = 0; (localString = br.readLine()) != null; i++){
            List<String> dataList = Arrays.asList(localString.split("\t"));
            HashMap<String, String> dataMap = new HashMap<>();
            for(int j = 0; j <= headerList.size()-1; j++) dataMap.put(headerList.get(j), dataList.get(j));
            String strpath = dataMap.get("Application.Request_Type") + "." + dataMap.get("Application.Channel") + "." + dataMap.get("Application.Product.Macroproduct");
            if(datapool.containsKey(strpath)){
                List<List<String>> tmplistlist = datapool.get(strpath);
                tmplistlist.add(dataList);
                datapool.replace(strpath, tmplistlist);
            }else{
                datapool.put(strpath, list2listlist(dataList));
            }

        }
        br.close(); fstream.close();

        System.out.println();
        //for(int i = 0; i <= headerList.size()-1; i++) dataMap.put(headerList.get(i), dataList.get(i));
        return datapool;
    }



    public List<String> getPoolKeys(){
        Set<String> keys = pool.keySet();
//        keys.contains("Headers");
        keys.remove("Headers");
        List<String> keyList = new ArrayList<>();
        keyList.addAll(keys);
        return keyList;
    }

    public void needOnly(String xmlType) {
        List<List<String>> curentPool = pool.get(xmlType);
        List<Map<String, String>> noBisPoolList = new ArrayList<>();
        List<Map<String, String>> bisPoolList = new ArrayList<>();
        for (List<String> list: curentPool) {
            Map<String, String> dataMap= new HashMap<>();
            for(int i = 0; i <= headers.size()-1; i++) dataMap.put(headers.get(i), list.get(i));
            if(dataMap.get("Applicant.BISClientCount").equals("0")){
                noBisPoolList.add(dataMap);
            }else{
                bisPoolList.add(dataMap);
            }
        }

    }
    public void needOnly(String xmlType, boolean clearMap) {
        needOnly(xmlType);
        if(clearMap){
            pool.clear();
        }
    }
}
