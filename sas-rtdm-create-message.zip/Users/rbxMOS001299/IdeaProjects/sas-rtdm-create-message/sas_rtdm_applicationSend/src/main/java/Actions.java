//package ru.iteco.isa.lr.script.SAS_RTDM_ApplicationSend;
import lrapi.lr;
/*
 * LoadRunner Java script. (Build: _build_number_)
 *
 * Script Description:
 *  Java JDK on Generators - C:\Program Files (x86)\Java\jdk1.8.0_151
 */

import com.ibm.mq.*;
import com.ibm.mq.constants.MQConstants;
//import lrapi.lr;

import java.util.*;

//import EPD;

public class Actions
{

    String hostname=lr.get_attrib_string("hostname");//"10.45.37.207";
    int port=Integer.parseInt(lr.get_attrib_string("port"));//1414;
    String channel = lr.get_attrib_string("channel");//"SYSTEM.BKR.CONFIG";
    //String userId=lr.get_attrib_string("userId");//"";
    //String password = lr.get_attrib_string("password");//"";
    String queueMgrName = lr.get_attrib_string("queueMgrName");//"QM1";
    String queueNameIn = lr.get_attrib_string("queueNameIn");//"RB.RTDM.IN"
    String queueNameOut = lr.get_attrib_string("queueNameOut");//"RB.DST.OUT"
    static List<Map<String, String>> noBisPoolList;
    static List<Map<String, String>> bisPoolList;
    static List<List<Map<String, String>>> poolList = null;
    static List<String> poolHeaders = null;

    MQQueueManager queueMgr = null;
    MQQueue getQueue = null;
    MQQueue putQueue = null;
    MQPutMessageOptions pmo = new MQPutMessageOptions();
    MQGetMessageOptions gmo = new MQGetMessageOptions();
    MQMessage requestMsg = new MQMessage();
    MQMessage responseMsg = new MQMessage();

    boolean debug = (lr.get_attrib_long("DEBUG") == 1);
    int bis_procent = (int)lr.get_attrib_long("bis_procent");

    String msgBody = null;
    Hashtable<Object, Object> ht = null;

    String outputFlg = lr.get_attrib_string("outputFlag");

    private Hashtable getMqProperties() {
        ht = new Hashtable<Object, Object>();
        ht.put(MQConstants.HOST_NAME_PROPERTY, hostname);
        ht.put(MQConstants.CHANNEL_PROPERTY, channel);
        ht.put(MQConstants.USER_ID_PROPERTY, "");
        ht.put(MQConstants.PASSWORD_PROPERTY, "");
        ht.put(MQConstants.PORT_PROPERTY, port);
        return ht;
    }

    public int init() throws Throwable {
        if((noBisPoolList == null) && (bisPoolList == null)){
            Datapool datapool = new Datapool("pool.txt");
            String xmlType = lr.get_attrib_string("xmlRequest_Type") + "." + lr.get_attrib_string("xmlChannel") + "." + lr.get_attrib_string("xmlMacroproduct");
            datapool.needOnly(xmlType, true);
            noBisPoolList = datapool.getNoBisPoolList();
            bisPoolList = datapool.getBisPoolList();
        }
        if(debug){
            Datapool datapool = new Datapool("pool.txt");
            poolList = new ArrayList<List<Map<String, String>>>();
            poolHeaders = datapool.getPoolKeys();
            for (String str : poolHeaders) {
                datapool.needOnly(str);
                poolList.add(datapool.getBisPoolList());
                poolList.add(datapool.getNoBisPoolList());
            }
            poolHeaders = null;
        }
        if(outputFlg.equals("MQ")){
            try {

                queueMgr = new MQQueueManager(queueMgrName,getMqProperties());

                putQueue = queueMgr.accessQueue(queueNameIn, MQConstants.MQOO_OUTPUT | MQConstants.MQOO_FAIL_IF_QUIESCING);

            } catch(Exception e) {
                lr.error_message(e.toString());
                lr.error_message("Error connecting to queue manager or accessing queues.");
                lr.exit(lr.EXIT_VUSER, lr.FAIL);
            }
        }

        return 0;

    }//end of init


    public int action() throws Throwable {
        XMLCreator requestMsg;
        String transactionName = "";

        if(!debug){
            poolList = new ArrayList<List<Map<String, String>>>();
            if (lr.eval_int("{bis_rand}") <= bis_procent) {
                poolList.add(bisPoolList);
            } else {
                poolList.add(noBisPoolList);
            }
        }

        for (List<Map<String, String>> data: poolList) {
            String isBis = "";
            if(data.get(0).get("Applicant.BISClientCount").equals("0"))
                isBis = ".noBIS";
            else isBis = ".BIS";
            transactionName = "SendToMQ_" + data.get(0).get("Application.Request_Type") + "." + data.get(0).get("Application.Channel") + "." + data.get(0).get("Application.Product.Macroproduct") + isBis;
            requestMsg = new XMLCreator(data);

            String requestMsgBody = requestMsg.getMsg();
            if (outputFlg.equals("console")) {
                System.out.println(requestMsgBody);
            } else if (outputFlg.equals("MQ")) {
//    			requestMsg.clearMessage();
                lr.start_transaction(transactionName);
                sendMessage2MQ(requestMsgBody);
                lr.end_transaction(transactionName, lr.AUTO);
            } else {
                System.out.println("неизвестный признак вывода");
            }

            lr.think_time(1);
        }

        /*else {
            if (lr.eval_int("{bis_rand}") <= bis_procent) {
                transactionName = "SendToMQ_" + bisPoolList.get(0).get("Application.Request_Type") + "." + bisPoolList.get(0).get("Application.Channel") + "." + bisPoolList.get(0).get("Application.Product.Macroproduct") + ".BIS";
                requestMsg = new XMLCreator(bisPoolList);
            } else {
                transactionName = "SendToMQ_" + bisPoolList.get(0).get("Application.Request_Type") + "." + bisPoolList.get(0).get("Application.Channel") + "." + bisPoolList.get(0).get("Application.Product.Macroproduct") + ".noBIS";
                requestMsg = new XMLCreator(noBisPoolList);
            }

            String requestMsgBody = requestMsg.getMsg();

//    	    System.out.println(requestMsgBody.length());

            if (outputFlg.equals("console")) {
                System.out.println(requestMsgBody);
            } else if (outputFlg.equals("MQ")) {
//    			requestMsg.clearMessage();
                lr.start_transaction(transactionName);
                sendMessage2MQ(requestMsgBody);
                lr.end_transaction(transactionName, lr.AUTO);
            } else {
                System.out.println("неизвестный признак вывода");
            }

            lr.think_time(0.1);
        }*/

        return 0;
    }//end of action

    public void sendMessage2MQ(String requestMsgBody){
        try {
            MQMessage msgIN = new MQMessage();
            msgIN.format = MQConstants.MQFMT_STRING;
            msgIN.encoding = 546; // todo: magic number.
            msgIN.characterSet = 1208; // todo: magic number.
            msgIN.replyToQueueName = queueNameOut;

            msgIN.writeString(requestMsgBody);

            MQPutMessageOptions pmo = new MQPutMessageOptions();
            putQueue.put(msgIN, pmo);
            System.out.println("messageId: " + msgIN.messageId);

        } catch(Exception e) {
            lr.error_message("Error sending message.");
            lr.exit(lr.EXIT_VUSER, lr.FAIL);
        }
    }

    public int end() throws Throwable {

        if(outputFlg.equals("MQ")){
            try {
                putQueue.close();
                queueMgr.close();
                ht = null;
            } catch(Exception e) {
                lr.error_message("Exception in closing the connections");
                lr.exit(lr.EXIT_VUSER, lr.FAIL);
            }
        }

        return 0;
    }//end of end
}
