
import lrapi.lr;

import java.io.*;
import java.nio.charset.Charset;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.text.SimpleDateFormat;
import java.util.*;

public class XMLCreator{

	static Map<String, String> data;

    public XMLCreator(List<Map<String, String>> list) {
        int size = list.size();
        if(size <= 0) throw new RuntimeException("no Data for this XML type in datapool");
        if(size == 1) data = list.get(0);
        int rnd = new Random().nextInt(size - 1);
        data = list.get(rnd);
    }

	private String getXMLContent(){
		String strpath = "xml/" + data.get("Application.Request_Type") + "." + data.get("Application.Channel") + "." + data.get("Application.Product.Macroproduct") + ".xml";
		Path path = Paths.get(strpath);
		String res = "";
		try{
			List<String> contents = Files.readAllLines(path, Charset.forName("UTF-8"));

			for(String content:contents){
				String tmp = res + content;
				res = tmp;
			}
		} catch (IOException e) {
			e.printStackTrace();
		}
		return res;
	}

	String createPoolStringProduct(BufferedReader _br, String _product) throws FileNotFoundException, IOException{
		String localString = null;
		while((localString = _br.readLine()) != null){
			if(localString.contains(_product)){
				return localString;
			}
		}
		return null;
	}

	HashMap parsePoolFileProduct(String _path, String _product) throws FileNotFoundException, IOException{
		FileInputStream fstream = new FileInputStream(_path);
		BufferedReader br = new BufferedReader(new InputStreamReader(fstream));

		HashMap<String, String> dataMap = new HashMap<String, String>();

		List<String> headerList = Arrays.asList(br.readLine().split("\t"));
		List<String> dataList = Arrays.asList(createPoolStringProduct(br, _product).split("\t"));
		br.close(); fstream.close();

		for(int i = 0; i <= headerList.size()-1; i++) dataMap.put(headerList.get(i), dataList.get(i));
		return dataMap;
	}

	String generateRandomCharCount(int _count, boolean _upperCase){
		//String rus = "абвгдеёжзийклмнопрстуфхцчъыьэюя";
		String eng = "abcdefghijklmnopqrstuvwxyz";
		String dig = "0123456789";
		if(_upperCase) eng = eng.toUpperCase();
		String chars = /*rus +*/ eng + dig;
		Random rnd = new Random(System.currentTimeMillis());

		String outString = "";
		for(int i = 0; i < _count; i++){
			outString += chars.charAt(rnd.nextInt(chars.length()) );
		}
		return outString;
	}

	String randomCodeFormat(String _formatString, boolean _upperCase) throws InterruptedException{
		String outString = "";
		int startid = _formatString.indexOf("%"), endid = 0;
		if(startid != -1){
			endid = _formatString.indexOf("%", startid+1);

			int encCount = Integer.parseInt(_formatString.substring(startid+1, endid));
			Thread.sleep(10);

			outString = randomCodeFormat(_formatString.substring(0, startid)+
							generateRandomCharCount(encCount, _upperCase)+
							_formatString.substring(endid+1, _formatString.length()),
					_upperCase);
			return outString;
		}
		return _formatString;
	}

	int randomIntBounds(int _lb, int _rb){
		Random rnd = new Random();
		if((_rb - _lb) <= 0){
			if(_lb >= 0){
				return _lb;
			}else{
				return 0;
			}
		}
		return _lb + rnd.nextInt(_rb - _lb);
	}

	Date addDays(Date _date, int _days){
		Calendar c = Calendar.getInstance();
		c.setTime(_date);
		c.add(Calendar.DATE, 1);
		return c.getTime();
	}

	public String getMsg() throws InterruptedException, IOException{
		String msgBody = null;
		String msgTemplate = null;

		String poolFilePathProduct = "productPool.txt";
		SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd'T'hh:mm:ss");
		SimpleDateFormat dateFormat2 = new SimpleDateFormat("MM/dd/yyyy hh:mm:ss");//08/30/2018 00:00:01

//		String[][] profileData = {
//			{"ShortApp", "Branch", "APL"},
//			{"ShortApp", "Branch", "CRC"},
//			{"ShortApp", "Branch", "OVR"},
//			{"ShortApp", "Branch", "REF"},
//			{"ShortApp", "DSA", "APL"},
//			{"ShortApp", "DSA", "CRC"},
//			{"ShortApp", "DSA", "OVR"},
//			{"ShortApp", "DSA", "REF"},
//			{"FullApp", "Branch", "APL"},
//			{"FullApp", "Branch", "CRC"},
//			{"FullApp", "Branch", "OVR"},
//			{"FullApp", "Branch", "REF"},
//			{"FullApp", "DSA", "APL"},
//			{"FullApp", "DSA", "CRC"},
//			{"FullApp", "DSA", "REF"},
//			{"AfterPDC", "Branch", "APL"},
//			{"AfterPDC", "Branch", "CRC"},
//			{"AfterPDC", "Branch", "OVR"},
//			{"AfterPDC", "Branch", "REF"},
//			{"AfterPDC", "DSA", "CRC"},
//			{"BeforeLO", "Branch", "APL"},
//			{"BeforeLO", "Branch", "CRC"},
//			{"BeforeLO", "Branch", "REF"},
//			{"CORP_Onboarding", "Branch", "NAC"},
//			{"RoleCalc", "Branch", "APL"},
//			{"RoleCalc", "Branch", "REF"},
//			{"TechCancel", "Branch", "APL"},
//			{"TechCancel", "Branch", "CRC"},
//			{"TechCancel", "Branch", "REF"},
//			{"TechDone", "Branch", "APL"},
//			{"TechDone", "Branch", "CRC"},
//			{"TechDone", "Branch", "OVR"},
//			{"TechDone", "Branch", "REF"},
//			{"TechDone", "DSA", "CRC"}
//		};

		data.put("Application.Request_Type", lr.get_attrib_string("xmlRequest_Type"));
		data.put("Application.Channel", lr.get_attrib_string("xmlChannel"));
		data.put("Application.Product.Macroproduct", lr.get_attrib_string("xmlMacroproduct"));

		data.put("Application.App_ID", randomCodeFormat("1-%7%-%4%-6", true)); //"1-6Y4UFVJ-RT16-6",
		data.put("Application.Ext_Request_ID", randomCodeFormat("1-%7%", true)); //"1-6Y5HECS",
		//data.put("Application.App_DT", dateFormat.format(new Date())); //"2018-06-27T14:14:20",
		data.put("Application.Product.Calculation_ID", randomCodeFormat("1-%7%", true)); //1-6Y4UFVY
		data.put("MessageID", randomCodeFormat("%8%-%4%-%4%-%4%-%12%", false)); //"6d341200-bd6d-4c44-a25c-abf7c7ddc5a8",
		//data.put("MessageDate", dateFormat.format(new Date())); //"2018-06-27T17:29:26",
		data.put("MessageDate", dateFormat2.format(new Date())); //08/30/2018 00:00:01
		data.put("CorrelationID", randomCodeFormat("%48%", false)); //"414d5120514d31202020202020202020dd1b305be174a826",
		data.put("ScoreCustomerObjectID", data.get("Application.App_ID").substring(0,9));

		data.putAll(parsePoolFileProduct(poolFilePathProduct, data.get("Application.Product.Macroproduct")));

		data.put("Doc_Series", Integer.toString(randomIntBounds(1000, 9999)));
		data.put("Doc_Number", Integer.toString(randomIntBounds(100000, 999999)));
		data.put("Doc_Issue_Date", dateFormat.format(new Date(-946771200000L + (Math.abs(new Random().nextLong()) % (77L * 365 * 24 * 60 * 60 * 1000)))));
		lr.output_message(data.get("Doc_Issue_Date"));


		data.put("Agreement.Agreement_End_DT", dateFormat.format(addDays(new Date(), 5)));
		data.put("Agreement.Agreement_Start_DT", dateFormat.format(addDays(new Date(), 5)));
		data.put("Application.Siebel_Synopsis_Doc_Link", data.get("Application.Siebel_Synopsis_Doc_Link")
				.replaceFirst("SWERowId0=(.*?)&", "SWERowId0="+data.get("Application.App_ID")+"&")
				.replace("&", "&amp;"));

		dataToParams();
		String tmpxmlval = getXMLContent();
		System.out.println(tmpxmlval);
		System.out.println();
		msgTemplate = lr.eval_string(tmpxmlval);

		String outputFlg = lr.get_attrib_string("outputFlag");
		if(outputFlg.equals("MQ")){
			msgBody = msgTemplate;

		} else {
			msgBody = msgTemplate;
		}
		lr.output_message(msgBody);
		return msgBody;
	}
	@Deprecated
	void _dataToParams(){
		String str = data.get("Application.Product.Monthly_Payment_Amt");
		data.replace("Application.Product.Monthly_Payment_Amt", str.replace(",", "."));
		str = data.get("Applicant.Declared_AVG_Monthly_Income");
		data.replace("Applicant.Declared_AVG_Monthly_Income", str.replace(",", "."));
		str = data.get("Applicant.After_Tax_Official_Income");
		data.replace("Applicant.After_Tax_Official_Income", str.replace(",", "."));
		str = data.get("Applicant.Calculation_Income");
		data.replace("Applicant.Calculation_Income", str.replace(",", "."));
		str = data.get("Applicant.Birth_Date");
		try{
			SimpleDateFormat dateFormat = new SimpleDateFormat("dd.MM.yyyy");
			Date date = dateFormat.parse(str);
			SimpleDateFormat dateFormat2 = new SimpleDateFormat("yyyy-MM-dd");
			str = dateFormat2.format(date);
		}catch(Exception e){
			lr.error_message("dateFormat error");
		}
		data.replace("Applicant.Birth_Date", str);
		str = data.get("Applicant.Spouse_Birth_DT");
		try{
			SimpleDateFormat dateFormat = new SimpleDateFormat("dd.MM.yyyy");
			Date date = dateFormat.parse(str);
			SimpleDateFormat dateFormat2 = new SimpleDateFormat("yyyy-MM-dd");
			str = dateFormat2.format(date);
		}catch(Exception e){
			lr.error_message("dateFormat error");
		}
		data.replace("Applicant.Spouse_Birth_DT", str);
		lr.save_string("", "BIS_Client");//Заделка к блоку бис-данных
		if(!data.get("Applicant.BISClientCount").equals("0"))
		    makeBisBlock();
		for (String key:data.keySet()){
			if(data.get(key).equals("null")){
				lr.save_string("", key);
			}else{
				lr.save_string(data.get(key), key);
			}
		}
	}

	void dataToParams(){
		String str = data.get("Application.Product.Monthly_Payment_Amt");
		data.replace("Application.Product.Monthly_Payment_Amt", str.replace(",", "."));
		str = data.get("Applicant.Declared_AVG_Monthly_Income");
		data.replace("Applicant.Declared_AVG_Monthly_Income", str.replace(",", "."));
		str = data.get("Applicant.After_Tax_Official_Income");
		data.replace("Applicant.After_Tax_Official_Income", str.replace(",", "."));
		str = data.get("Applicant.Calculation_Income");
		data.replace("Applicant.Calculation_Income", str.replace(",", "."));
		str = data.get("Applicant.Main_OKVED");
		data.replace("Applicant.Main_OKVED", str.replace(",", "."));
		str = data.get("Applicant.Birth_Date");
		if(!(str.equals("null"))){
			try{
				SimpleDateFormat dateFormat = new SimpleDateFormat("dd.MM.yyyy");
				Date date = dateFormat.parse(str);
				SimpleDateFormat dateFormat2 = new SimpleDateFormat("yyyy-MM-dd");
				str = dateFormat2.format(date);
			}catch(Exception e){
				lr.error_message("dateFormat error on value \"Applicant.Birth_Date\"");
				lr.error_message("Converting dateFormat from \"dd.MM.yyyy\" to \"yyyy-MM-dd\" failed. \r\n Your Input value: " + str + " not supported");
			}
			data.replace("Applicant.Birth_Date", str);
		}

		str = data.get("Applicant.getGos_Registration_Date");
		if(!(str.equals("null"))){
			try{
				SimpleDateFormat dateFormat = new SimpleDateFormat("dd.MM.yyyy");
				Date date = dateFormat.parse(str);
				SimpleDateFormat dateFormat2 = new SimpleDateFormat("yyyy-MM-dd");
				str = dateFormat2.format(date);
			}catch(Exception e){
				lr.error_message("dateFormat error on value \"Applicant.getGos_Registration_Date\"");
				lr.error_message("Converting dateFormat from \"dd.MM.yyyy\" to \"yyyy-MM-dd\" failed. \r\n Your Input value: " + str + " not supported");
			}
			data.replace("Applicant.Birth_Date", str);
		}
		str = data.get("Applicant.Spouse_Birth_DT");
		if(!(str.equals("null"))){
			try{
				SimpleDateFormat dateFormat = new SimpleDateFormat("dd.MM.yyyy");
				Date date = dateFormat.parse(str);
				SimpleDateFormat dateFormat2 = new SimpleDateFormat("yyyy-MM-dd");
				str = dateFormat2.format(date);
			}catch(Exception e){
				lr.error_message("dateFormat error on value \"Applicant.Spouse_Birth_DT\"");
				lr.error_message("Converting dateFormat from \"dd.MM.yyyy\" to \"yyyy-MM-dd\" failed. \r\n Your Input value: " + str + " not supported");
			}
			data.replace("Applicant.Spouse_Birth_DT", str);
		}
		lr.save_string("", "BIS_Client");//Заделка к блоку бис-данных
		if(!data.get("Applicant.BISClientCount").equals("0"))
			makeBisBlock();
		for (String key:data.keySet()){
			if(data.get(key).equals("null")){
				lr.save_string("", key);
			}else{
				lr.save_string(data.get(key), key);
			}
		}
	}

	void makeBisBlock(){

        FileInputStream fstream = null;
        try {
            fstream = new FileInputStream("BIS_pool.txt");
            BufferedReader br = new BufferedReader(new InputStreamReader(fstream));
            String[] tmp = null;
            String line = null;
            List<String> bis_client_id = new ArrayList<String>();
            List<String> bis_branch_id = new ArrayList<String>();
            while((line = br.readLine()) != null){
                tmp = line.split("\t");
                bis_client_id.add(tmp[0]);
                bis_branch_id.add(tmp[1]);
                tmp = null;
                line = null;
            }
            br.close(); fstream.close();
            int size = bis_client_id.size();
            System.out.println("size: " + size);
            if(size > 0){
                int r_int = randomIntBounds(0, size - 1);
                //<BIS_Client><BIS_Client_ID>1D1738</BIS_Client_ID><Branch_BIS_ID>R19</Branch_BIS_ID></BIS_Client>
                String res = "<BIS_Client><BIS_Client_ID>" + bis_client_id.get(r_int) +
                        "</BIS_Client_ID><Branch_BIS_ID>" + bis_branch_id.get(r_int) + "</Branch_BIS_ID></BIS_Client>";

                lr.save_string(res, "BIS_Client");
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
	}
}