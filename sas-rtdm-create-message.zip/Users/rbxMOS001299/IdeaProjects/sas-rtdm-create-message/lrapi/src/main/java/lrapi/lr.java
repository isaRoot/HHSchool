package lrapi;

import java.util.HashMap;
import java.util.Map;

public class lr
//        extends lr
{
    public static final int PASS = 0;
    public static final int FAIL = 1;
    public static final int AUTO = 2;
    public static final int STOP = 3;
    public static final int EXIT_VUSER = 0;
    public static final int EXIT_ACTION_AND_CONTINUE = 1;
    public static final int EXIT_ITERATION_AND_CONTINUE = 2;
    public static final int EXIT_VUSER_AFTER_ITERATION = 3;
    public static final int EXIT_VUSER_AFTER_ACTION = 4;
    public static final boolean EQUALS = true;
    public static final boolean NOT_EQUALS = false;
    public static final int MSG_CLASS_BRIEF_LOG = 1;
    public static final int MSG_CLASS_RESULT_DATA = 2;
    public static final int MSG_CLASS_PARAMETERS = 4;
    public static final int MSG_CLASS_FULL_TRACE = 8;
    public static final int MSG_CLASS_ADVANCED_TRACE = 8;
    public static final int MSG_CLASS_EXTENDED_LOG = 16;
    public static final int MSG_CLASS_JIT_LOG_ON_ERROR = 512;
    public static final int MSG_ERROR = 1;
    public static final int MSG_SEND = 2;
    public static final int MSG_LOCATION = 4;
    public static final int SWITCH_OFF = 0;
    public static final int SWITCH_ON = 1;
    public static final int SWITCH_DEFAULT = 2;

    private static Map<String, String> params = new HashMap();
    private static Map<String, String> attribs = attributes.get();

    public static int output_message(String str){
        System.out.println(str);
        return 0;
    }

    public static int error_message(String str){
        System.out.println("Error:");
        System.out.println(str);
        return 0;
    }

    public static int save_string(String param_value, String param_name){
        if(params.containsKey(param_name)){
            params.replace(param_name, param_value);
        }else{
            params.put(param_name, param_value);
        }
        return 0;
    }

    @SuppressWarnings("TODO: Make it look as in HP(with patterns?)")
    public static String eval_string(String param_name) {
        if(params.containsKey(param_name)){
            return params.get(param_name);
        }else{
            return param_name;
        }

    }
    public static int eval_int(String param_name) {
        if(params.containsKey(param_name)){
            return Integer.parseInt(params.get(param_name));
        }else{
            return 0;
        }

    }

    public static long get_attrib_long(String attrib_name) {
        if(attribs.containsKey(attrib_name)){
            return Long.parseLong(attribs.get(attrib_name));
        }else{
            return 0L;
        }

    }

    public static String get_attrib_string(String attrib_name){
        if(attribs.containsKey(attrib_name)){
            return attribs.get(attrib_name);
        }else{
            return "";
        }
    }

    @SuppressWarnings("TODO: some better worked")
    public static void exit(int continuation_option, int exit_status){
        System.exit(exit_status);
    }
    @SuppressWarnings("TODO: ")
    public static void start_transaction(String transaction_name) {

    }
    @SuppressWarnings("TODO: ")
    public static void end_transaction(String transaction_name, int status) {

    }

    public static void think_time(double thinkTime) {
        double pause_coef = 1000L;
        double pause = pause_coef * thinkTime;
        try {
            Thread.sleep((long) pause);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }
}
