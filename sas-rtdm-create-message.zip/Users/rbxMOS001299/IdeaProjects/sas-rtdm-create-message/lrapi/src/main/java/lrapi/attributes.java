package lrapi;

import java.util.HashMap;
import java.util.Map;

public class attributes {
    public static Map<String, String> get(){
        Map<String, String> attribs = new HashMap();
        attribs.put("bis_procent", "66");
        attribs.put("channel", "SYSTEM.BKR.CONFIG");
        attribs.put("DEBUG", "1");
        attribs.put("hostname", "10.45.37.207");
        attribs.put("outputFlag", "MQ");
        attribs.put("password", "Qq123456");
        attribs.put("port", "1414");
        attribs.put("queueMgrName", "QM1");
        attribs.put("queueNameIn", "RB.SIEBEL.IN.ASYNC");
        attribs.put("queueNameOut", "RB.SIEBEL.OUT.ASYNC");
        attribs.put("userId", "rbxMOS002272");
        attribs.put("xmlChannel", "Branch");
        attribs.put("xmlMacroproduct", "APL");
        attribs.put("xmlRequest_Type", "ShortApp");

        return attribs;
    }
}
