package lrapi;

import java.io.*;
import java.util.HashMap;
import java.util.Map;

public class Config {
    private Map<String, HashMap> cfg = new HashMap();

    public Map<String, HashMap> getCfg() {
        return cfg;
    }

    public void setCfg(Map<String, HashMap> cfg) {
        this.cfg = null;
        this.cfg = cfg;
    }

    public void readCfg() throws Exception {
        String path = "C:\\Users\\rbxMOS001299\\Desktop\\isa\\SAS_RTDM_PreapproveSend\\";
        String default_usp = "";//default.usp = Actions Order and pacings, usw(not important)
        //scriptname.usr = default.cfg, default.usp, scriptname.prm, actions.java, extrafiles...
        String scriptname_usr = "SAS_RTDM_PreapproveSend.usr";
        //default.cfg = usp-file, attributes, extrafiles, JDK, log_options, think_times, usw..
        //scriptname.prm = params definition
        String default_cfg = "default.cfg";
        InputStream fis = new FileInputStream(path + scriptname_usr);
        BufferedReader br = new BufferedReader(new InputStreamReader(fis));
        String str;
        String tmp = "";
        Map<String, HashMap> cfg = getCfg();
        while((str = br.readLine()) != null){
            if(str.startsWith("[") && str.endsWith("]")){
                tmp = str.substring(1, str.length() - 1);
            }else {
                String[] pair = str.split("=");
                if(pair.length == 1) pair = new String[]{pair[0], ""};
                if (!cfg.containsKey(tmp)) {
                    HashMap<String, String> hm_tmp = new HashMap<>();
                    hm_tmp.put(pair[0], pair[1]);
                    cfg.put(tmp, hm_tmp);
                } else {
                    HashMap<String, String> hm_tmp = cfg.get(tmp);
                    hm_tmp.put(pair[0], pair[1]);
                    cfg.replace(tmp, hm_tmp);
                }
            }
        }
        setCfg(cfg);
    }
}
