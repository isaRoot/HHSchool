package lrapi;

import java.net.URL;
import java.net.URLClassLoader;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.text.SimpleDateFormat;
import java.util.Date;

class Scratch {


    public static void main(String[] args) throws Exception{
        Config config = new Config();
        String str = "2018-06-20";
        try{
            SimpleDateFormat dateFormat = new SimpleDateFormat("dd.MM.yyyy");
            Date date = dateFormat.parse(str);
            SimpleDateFormat dateFormat2 = new SimpleDateFormat("yyyy-MM-dd");
            str = dateFormat2.format(date);

        }catch(Exception e){

            if(!str.equals(new SimpleDateFormat("yyyy-MM-dd"))) {
                lr.error_message("dateFormat error on value \"Applicant.Birth_Date\"");
                lr.error_message("Converting dateFormat from \"dd.MM.yyy\" to \"yyyy-MM-dd\" failed. \r\n Your Input value: " + str + " not supported");
            }else{
                System.out.println("dateFormat on value \"Applicant.Birth_Date\" is correct");
            }
        }
        System.out.println();
//        config.readCfg();
//        prm.test();
        Path path = Paths.get("");
        System.out.println("_ABS = " + path.toAbsolutePath());
        System.out.println("REAL = " + path.toRealPath());
        long f = Files.size(path);
        System.out.println(config.getClass());
        System.out.println(config.getClass().getPackage());
        System.out.println(config.getClass().getName());
        System.out.println(config.getClass().getSimpleName());
        System.out.println(config.getClass().getTypeName());
        System.out.println(config.getClass().getCanonicalName());
        System.out.println(config.getClass().getClassLoader());
        System.out.println(config);
        ClassLoader cl = ClassLoader.getSystemClassLoader();

        URL[] urls = ((URLClassLoader)cl).getURLs();

        for(URL url: urls)
            System.out.println(url.getFile());
        System.out.println();

//        System.out.println(properties.toString());

    }
}