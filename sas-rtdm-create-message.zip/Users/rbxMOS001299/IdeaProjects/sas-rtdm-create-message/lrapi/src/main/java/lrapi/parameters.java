package lrapi;

import java.util.HashMap;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class parameters {
    private static Map<String, String> params = new HashMap();
    public void test(){
        setParams();
        final String regex = "\\{(.*?)\\}";
//        final String regex = "(\\{.*?\\})";
//        final String regex = "{([a-zA-Z0-9-\\_/]*)}";
        final Pattern pattern = Pattern.compile(regex);
        Matcher matcher;
        String str = testString();
        //str = str.replaceAll(regex, Integer.toString(2));


        int i = 0;
        StringBuffer sb = new StringBuffer();
        matcher = pattern.matcher(str);
        while (matcher.find(i)) {

            i = matcher.start() + 1;
            matcher.appendReplacement(sb, getParam(matcher.group()));
            matcher.appendTail(sb);
            str = sb.toString();
            System.out.println(matcher.group());
            System.out.println("str = " + str);
            System.out.println("sb = " + sb);
            System.out.println();
        };
        System.out.println(str);
    }

    private String getParam(String group) {
        String key = group.substring(1, group.length() - 1);
        String value;
        if(params.containsKey(key)){
            value = params.get(key);
            System.out.println("Parameter Substitution: parameter \"" + key + "\" = \"" + value + "\"");
            return value;
        }else{
            System.out.println("The string '" + key + "' with parameter delimiters is not a parameter.");
            return group;
        }
    }

    private void setParams() {
        params.put("Application.Ext_Request_ID", "28644725_1-E5J47Y3");
    }

    static String testString(){
        return "<?xml version=\"1.0\" encoding=\"UTF-8\"?><Application xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\"><Ext_Request_ID>{Application.Ext_Request_ID}</Ext_Request_ID><MA_application_ID>{Application.MA_application_ID}</MA_application_ID><App_ID>{Application.App_ID}</App_ID><App_DT>{Application.App_DT}</App_DT><Point_Number>{Application.Point_Number}</Point_Number><Branch_Code>{Application.Branch_Code}</Branch_Code><Applicant><Applicant_ID>{Applicant.Applicant_ID}</Applicant_ID><Client_ID>{Applicant.Client_ID}</Client_ID><Last_Name>{Applicant.Last_Name}</Last_Name><First_Name>{Applicant.First_Name}</First_Name><Middle_Name>{Applicant.Middle_Name}</Middle_Name><Sex>{Applicant.Sex}</Sex><Previous_Last_Name>{Applicant.Previous_Last_Name}</Previous_Last_Name><Citizenship>{Applicant.Citizenship}</Citizenship><SNILS>{Applicant.SNILS}</SNILS><Salary_Flag>{Applicant.Salary_Flag}</Salary_Flag><Birth_Date>{Applicant.Birth_Date}</Birth_Date><Birth_Place>{Applicant.Birth_Place}</Birth_Place><Education>{Applicant.Education}</Education><Relationship>{Applicant.Relationship}</Relationship><Work_Last_3y_Jobs_CNT>{Applicant.Work_Last_3y_Jobs_CNT}</Work_Last_3y_Jobs_CNT><Declared_AVG_Monthly_Income>{Applicant.Declared_AVG_Monthly_Income}</Declared_AVG_Monthly_Income><After_Tax_Official_Income>{Applicant.After_Tax_Official_Income}</After_Tax_Official_Income><Dependent_Persons_CNT>{Applicant.Dependent_Persons_CNT}</Dependent_Persons_CNT><Other_Monthly_Payment>{Applicant.Other_Monthly_Payment}</Other_Monthly_Payment><Client_Realty_Owner>{Applicant.Client_Realty_Owner}</Client_Realty_Owner><Client_Car_Owner>{Applicant.Client_Car_Owner}</Client_Car_Owner><Client_Business_Owner>{Applicant.Client_Business_Owner}</Client_Business_Owner><Salary_Income_To_Account>{Applicant.Salary_Income_To_Account}</Salary_Income_To_Account>{BIS_Client}</Applicant></Application>";
    }
}
